str=$(cat -)
str=${str//s/a}
str=${str//x/c}
echo ${str//qq/rr}
