str=$(cat -)
str=${str//j/i}
str=${str//K/n}
echo ${str//oo/ww}
