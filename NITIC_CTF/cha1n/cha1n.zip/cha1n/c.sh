str="njtjxpxtfwx()s1Kpx()s1Kpx()s1Kpx()s1Kpx()s1Kp5x8mb83"
str=${str//()/h}
str=${str//p/_}
echo ${str//w/oo}