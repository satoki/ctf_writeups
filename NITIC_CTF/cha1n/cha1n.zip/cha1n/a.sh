str=$(cat -)
str=${str//3/\}}
str=${str//8/o}
echo ${str//ww/qq}