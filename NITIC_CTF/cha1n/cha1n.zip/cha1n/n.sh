str=$(cat -)
echo ${str//rr/\{}