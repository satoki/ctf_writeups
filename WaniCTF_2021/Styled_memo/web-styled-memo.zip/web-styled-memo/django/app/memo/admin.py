from app.memo.models import Memo

from django.contrib import admin

admin.site.register(Memo)
