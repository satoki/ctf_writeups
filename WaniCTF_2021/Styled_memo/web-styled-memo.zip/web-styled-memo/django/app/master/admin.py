from app.master.models import User

from django.contrib import admin

admin.site.register(User)
