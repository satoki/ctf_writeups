from django.apps import AppConfig


class MasterConfig(AppConfig):
    name = "app.master"
