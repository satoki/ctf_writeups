<template>
  <div class="container">

    <NuxtPage/>
  </div>
</template>
