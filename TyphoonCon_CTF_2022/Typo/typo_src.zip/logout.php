<?php

header("Creators: @CTFCreators");
@session_destroy();
header("Location: /index.php");