module.exports = {
  flag: 'HarekazeCTF{DUMMY}'
};