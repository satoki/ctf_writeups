from flask import Flask, request, make_response, render_template, redirect, url_for
from lxml import etree
import os
import secrets
import uuid

app = Flask(__name__)

cards_directory = "cards"
os.makedirs(cards_directory, exist_ok=True)

@app.route('/')
def index():
    user_id = request.cookies.get('user_id')
    if not user_id:
        response = make_response(render_template('home.html'))
        user_id = secrets.token_hex(16)
        response.set_cookie('user_id', user_id)
        return response
    else:
        return render_template('home.html')

@app.route('/send', methods=['GET', 'POST'])
def send():
    if request.method == 'POST':
        recipient_id = request.form['recipient_id']
        card_data = request.form['card_data']

        card_data = card_data.replace('&','')
        card_data = card_data.replace('%','')

        file_name = f"{recipient_id}_{uuid.uuid4()}.xml"
        file_path = os.path.join(cards_directory, file_name)

        with open(file_path, 'w') as file:
            file.write(card_data)
        
        return redirect(url_for('index'))
    else:
        return render_template('send.html')

@app.route('/view')
def view():
    user_id = request.cookies.get('user_id')
    card_files = [f for f in os.listdir(cards_directory) if f.startswith(user_id)]
    cards = []

    parser = etree.XMLParser(load_dtd=True, no_network=False, resolve_entities=True)

    for card_file in card_files:
        file_path = os.path.join(cards_directory, card_file)
        try:
            with open(file_path, 'rb') as file:
                xml_data = etree.parse(file, parser)
                message = xml_data.xpath('/card/message/text()')
                if message:
                    cards.append(message[0])
                else:
                    cards.append("Invalid card format.")
        except etree.XMLSyntaxError as e:
            cards.append(f"Error parsing XML: {e}")
    
    return render_template('view.html', cards=cards)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=60001)
