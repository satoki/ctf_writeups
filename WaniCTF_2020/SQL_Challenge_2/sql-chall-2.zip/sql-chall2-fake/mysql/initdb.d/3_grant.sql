REVOKE ALL PRIVILEGES ON `test\_db`.* FROM 'wani'@'%';
GRANT SELECT ON `test\_db`.* TO 'wani'@'%';