import Fastify from "fastify";
import view from "@fastify/view";
import fastifyCookie from "@fastify/cookie";
import ejs from "ejs";

const fastify = Fastify();

const notes = [
  { id: 1, title: "Note 1", content: "This is a note", adminOnly: false },
  { id: 2, title: "Note 2", content: "This is another note", adminOnly: false },
  { id: 3, title: "Flag", content: process.env.FLAG, adminOnly: true },
];

fastify.register(fastifyCookie, {
  secret: process.env.COOKIE_SECRET,
  parseOptions: {},
});

fastify.register(view, {
  engine: { ejs },
  root: "views",
});

const isAdmin = (req) => {
  const { valid, value } = req.unsignCookie(req.cookies.authenticated || "");
  return valid && value === "true";
}

fastify.get("/", async (req, res) => {
  const q = String(req.query.q);
  if (!q)
    return res.viewAsync("index.ejs", { notes: {} });
  const filteredNotes = notes.filter(note =>
    (note.title.includes(q) || note.content.includes(q)) &&
    (!note.adminOnly || isAdmin(req))
  );
  return await res.viewAsync("index.ejs", { notes: filteredNotes });
});

fastify.get("/note/:id", async (req, res) => {
  const { id } = req.params;
  const note = notes.find(note => note.id === Number(id) && (!note.adminOnly || isAdmin(req)));
  if (!note)
    return res.redirect("/");
  return await res.viewAsync("note.ejs", { note });
});

fastify.get("/admin", async (req, res) => {
  const secret = String(req.query.secret);
  if (secret === process.env.ADMIN_SECRET) {
    res.setCookie("authenticated", "true", { path: "/", httpOnly: true, signed: true });
    return res.redirect("/");
  }
  res.code(401).send(":(");
});

fastify.listen({ port: 3333, host: "0.0.0.0" });
