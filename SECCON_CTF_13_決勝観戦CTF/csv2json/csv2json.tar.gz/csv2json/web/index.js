import Fastify from "fastify";
import fs from "fs";
import path from "path";

const fastify = Fastify();

fastify.get("/", (request, reply) => {
    reply.type("text/html").send(fs.readFileSync(path.resolve("index.html")));
});

fastify.listen({ port: process.env.PORT, host: "0.0.0.0" });
