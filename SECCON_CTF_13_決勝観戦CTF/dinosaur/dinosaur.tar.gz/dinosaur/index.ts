// deno --no-prompt index.ts
try {
    Object.prototype[prompt("key")!] = prompt("value")!;
    const response = await fetch("http://localhost/");
    if (response.ok) console.log("Alpaca{REDACTED}");
} catch (error) {
    console.log("Error");
}
