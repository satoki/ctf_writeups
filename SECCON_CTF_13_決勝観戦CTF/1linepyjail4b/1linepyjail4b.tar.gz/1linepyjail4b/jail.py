print(eval(code, {"__builtins__": None}) if len(code := (input("jail> ").strip())) <= 86 else ":(")
