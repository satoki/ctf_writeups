#include <stdio.h>
#include <stdlib.h>

void win()
{
    system("/bin/sh");
}

void vuln()
{
    char buf[64];
    printf("Why you wanna shell? ");
    fgets(buf, 64, stdin);
    printf(buf);
    puts("Hmm...Good bye!");
    return;
}

int main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    vuln();
    return 0;
}
