<!DOCTYPE html>
<html lang="en">
<head>
<title>Hidden Content</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {font-family: "Lato", sans-serif}
.mySlides {display: none}
</style>
</head>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#" class="w3-bar-item w3-button w3-padding-large">HOME</a>
    <a href="#ia" class="w3-bar-item w3-button w3-padding-large w3-hide-small">IA</a>
    <a href="#flag" class="w3-bar-item w3-button w3-padding-large w3-hide-small">FLAG</a>
    <a href="javascript:void(0)" class="w3-padding-large w3-hover-red w3-hide-small w3-right"><i class="fa fa-search"></i></a>
  </div>
</div>

<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:46px">
  <a href="#ia" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">IA</a>
  <a href="#flag" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">FLAG</a>

</div>

<!-- Page content -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">

  <!-- Automatic Slideshow Images -->
  <div class="mySlides w3-display-container w3-center">
    <img src="./img/firstimage.png" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>IA</h3>
      <p><b>an ally or enemy?</b></p>   
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="./img/firstimage.png" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>Artificial Intelligence ?</h3>
      <p><b>Revolution or Destruction?</b></p>    
    </div>
  </div>
  <div class="mySlides w3-display-container w3-center">
    <img src="./img/firstimage.png" style="width:100%">
    <div class="w3-display-bottommiddle w3-container w3-text-white w3-padding-32 w3-hide-small">
      <h3>midjourney</h3>
      <p><b>is it really a journey?</b></p>    
    </div>
  </div>

  <!-- The Band Section -->
  <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="ia">
    <h2 class="w3-wide">Generated</h2>
    <p class="w3-opacity"><i>IA</i></p>
    <p class="w3-justify">IA has revolutionized various industries by streamlining tasks, reducing costs, improving accuracy and freeing up valuable time for humans to focus on higher-level tasks. It has also created new job opportunities in fields such as data science and AI development.</p>
    <div class="w3-row w3-padding-32">
      <div class="w3-third">
        <p>Name</p>
        <img src="./img/blueman.jpeg" class="w3-round w3-margin-bottom" alt="Random Name" style="width:60%">
      </div>
      <div class="w3-third">
        <p>Name</p>
        <img src="./img/orangeman.jpeg" class="w3-round w3-margin-bottom" alt="Random Name" style="width:60%">
      </div>
      <div class="w3-third">
        <p>Name</p>
        <img src="./img/space.jpeg" class="w3-round" alt="Random Name" style="width:60%">
      </div>
    </div>
  </div>

  <!-- The Tour Section -->
  <div class="w3-black" id="flag">
    <div class="w3-container w3-content w3-padding-64" style="max-width:800px">
      <h2 class="w3-wide w3-center">My flag zone!</h2>
      <p class="w3-opacity w3-center"><i>Remember that we can read it if we want to.</i></p><br>


      <div class="w3-row-padding w3-padding-32" style="margin:0 -16px">
        <h1 class="w3-wide w3-center"> In Order to read the flag, look behind the scenes, or behind my screen as shown below. </h1>
        <img src="./img/secteam.jpeg" class="w3-round" alt="Random Name" style="width:100%">
        <h3 class="w3-wide w3-center">flag here: </h3> 
        <?php  $FLAG = "Merctf{FAKE_FLAG}" ; ?>
      </div>

    </div>
  </div>

</div>

<script>
// Automatic Slideshow - change image every 4 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 4000);    
}

// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}

// When the user clicks anywhere outside of the modal, close it
var modal = document.getElementById('ticketModal');
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>

</body>
</html>
