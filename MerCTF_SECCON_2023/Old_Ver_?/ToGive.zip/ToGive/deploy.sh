#!/bin/bash

echo " "
tput setaf 4;
echo "#########################################################################"
echo "Installing Docker..."
echo "#########################################################################"
if [ -x "$(command -v docker)" ]; then
  echo  " "
  tput setaf 2; 
  echo "Docker already installed, skipping."
else
  curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh
  echo " "
  tput setaf 2; 
  echo "Docker installed!!!"
fi

tput setaf 3;
echo " "
echo "#########################################################################"
echo " "

tput setaf 4;
echo "#########################################################################"
echo "Checking Docker status"
echo "#########################################################################"

if systemctl is-active docker >/dev/null 2>&1; then
  echo " "
  tput setaf 2;
  echo "Docker is running."
else
  echo " "
  tput setaf 1;
  echo "Docker is not running. Please run docker and try again."
  echo "You can run docker service using sudo systemctl start docker"
  exit 1
fi

tput setaf 3;
echo " "
echo "#########################################################################"
echo " "

tput setaf 4;
echo "#########################################################################"
echo "Deploying the challenge"
echo "#########################################################################"
echo " "

echo "Building the docker image .."
sudo docker build . -t "phpchall"
echo " "
echo "Building terminated, Running the image ..."
sudo docker run -d -p 8888:8888 phpchall

tput setaf 3;
echo " "
echo "#########################################################################"
echo " "

tput setaf 2;
echo " "
echo "Application is deployed and running on port 8888. You can Visit the website on IP:8888"
