a: int
b
c = 'no annotation'
x: int = 10
y: str = 'annotation'
z: tuple = (1, 2, 3)
confirm_subscr = {}
confirm_subscr['test'] = 'works'
