from __future__ import unicode_literals

ustr = u'Unicode'
bstr = b'Bytes'
dstr = 'Default'
