x = { 'one': 1, 'two': 2 }
if x['one'] == 1:
    print "Correct!"
x['three'] = 3
