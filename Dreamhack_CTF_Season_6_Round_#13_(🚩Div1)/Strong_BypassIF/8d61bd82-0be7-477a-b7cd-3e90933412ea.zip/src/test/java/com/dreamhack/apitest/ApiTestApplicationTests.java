package com.dreamhack.apitest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
